import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { mode, prompt, duration, aspectRatio, images } = body ?? {};
    if (!["text", "image", "reference"].includes(mode)) {
      return NextResponse.json({ error: "Invalid generation mode." }, { status: 400 });
    }
    if (!prompt || typeof prompt !== "string" || prompt.trim().length < 3) {
      return NextResponse.json({ error: "Please enter a video prompt." }, { status: 400 });
    }
    if (![5, 10, 15, 20, 25, 30].includes(Number(duration))) {
      return NextResponse.json({ error: "Duration must be between 5 and 30 seconds." }, { status: 400 });
    }
    if (mode !== "text" && (!Array.isArray(images) || images.length === 0)) {
      return NextResponse.json({ error: "Upload at least one reference image." }, { status: 400 });
    }

    // Demo response only. Connect a real video-generation provider here.
    // Do not expose provider API keys in client-side code.
    return NextResponse.json({
      success: true,
      demo: true,
      jobId: `demo_${Date.now()}`,
      status: "queued",
      message: "Demo job created. Connect a video API adapter to generate a real video.",
      settings: { mode, duration: Number(duration), aspectRatio, imageCount: images?.length ?? 0 }
    });
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }
}
