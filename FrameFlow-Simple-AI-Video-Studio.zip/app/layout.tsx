import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "FrameFlow — AI Video Studio",
  description: "Simple text, image, and reference to video studio.",
  viewport: { width: "device-width", initialScale: 1, maximumScale: 1 }
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
