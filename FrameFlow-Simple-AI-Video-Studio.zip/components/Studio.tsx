"use client";

import { useRef, useState } from "react";
import { Film, ImagePlus, Layers3, Sparkles, Upload, X, Clock3, Download, Play, Clapperboard, CheckCircle2, AlertCircle } from "lucide-react";

type Mode = "text" | "image" | "reference";
type PickedImage = { name: string; url: string };

const modes: { id: Mode; title: string; subtitle: string; icon: typeof Film }[] = [
  { id: "text", title: "Text to Video", subtitle: "Create from a prompt", icon: Film },
  { id: "image", title: "Image to Video", subtitle: "Animate one image", icon: ImagePlus },
  { id: "reference", title: "Reference to Video", subtitle: "Guide with multiple images", icon: Layers3 },
];

export default function Studio() {
  const [mode, setMode] = useState<Mode>("text");
  const [prompt, setPrompt] = useState("");
  const [duration, setDuration] = useState(5);
  const [ratio, setRatio] = useState("16:9");
  const [images, setImages] = useState<PickedImage[]>([]);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<{kind:"success"|"error"; text:string}|null>(null);
  const [job, setJob] = useState<{id:string; message:string}|null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  function changeMode(next: Mode) {
    setMode(next); setNotice(null); setJob(null);
    if (next === "image" && images.length > 1) setImages(images.slice(0,1));
  }

  function addFiles(list: FileList | null) {
    if (!list) return;
    const max = mode === "image" ? 1 : 5;
    const incoming = Array.from(list).filter(f => f.type.startsWith("image/"));
    const room = max - images.length;
    const next = incoming.slice(0, room).map(file => ({ name: file.name, url: URL.createObjectURL(file) }));
    setImages(prev => [...prev, ...next]);
    setNotice(null);
  }

  function removeImage(index: number) {
    setImages(prev => {
      URL.revokeObjectURL(prev[index].url);
      return prev.filter((_, i) => i !== index);
    });
  }

  async function generate() {
    setNotice(null); setJob(null);
    if (!prompt.trim()) { setNotice({kind:"error", text:"Write a prompt describing your video first."}); return; }
    if (mode !== "text" && images.length === 0) { setNotice({kind:"error", text:"Upload at least one image reference first."}); return; }
    setBusy(true);
    try {
      const res = await fetch("/api/generate", {
        method: "POST", headers: {"Content-Type":"application/json"},
        body: JSON.stringify({ mode, prompt, duration, aspectRatio: ratio, images: images.map(i => i.name) })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not create generation job.");
      setJob({id:data.jobId, message:data.message});
      setNotice({kind:"success", text:"Demo request accepted. No real video has been rendered yet."});
    } catch (e) {
      setNotice({kind:"error", text:e instanceof Error ? e.message : "Something went wrong."});
    } finally { setBusy(false); }
  }

  return (
    <main className="shell">
      <header className="topbar">
        <a className="brand" href="#"><span className="brandIcon"><Clapperboard size={19}/></span><span>FRAME<span className="brandAccent">FLOW</span></span></a>
        <span className="badge"><span className="dot"/> LEARNING MODE</span>
      </header>

      <section className="hero">
        <div className="eyebrow"><Sparkles size={14}/> SIMPLE AI VIDEO STUDIO</div>
        <h1>Turn your ideas into <span>motion.</span></h1>
        <p>Create a video from text, a single image, or a set of visual references.</p>
      </section>

      <section className="workspace">
        <div className="modeGrid" role="tablist" aria-label="Video generation mode">
          {modes.map(item => {
            const Icon = item.icon;
            return <button key={item.id} role="tab" aria-selected={mode===item.id} className={`modeCard ${mode===item.id ? "active" : ""}`} onClick={()=>changeMode(item.id)}>
              <span className="modeIcon"><Icon size={20}/></span>
              <span className="modeText"><strong>{item.title}</strong><small>{item.subtitle}</small></span>
              <span className="radio"/>
            </button>;
          })}
        </div>

        <div className="editorGrid">
          <section className="panel editor">
            <div className="panelHead"><div><span className="step">01</span><h2>Describe your video</h2></div><span className="optional">PROMPT</span></div>
            <label className="fieldLabel" htmlFor="prompt">Your prompt</label>
            <textarea id="prompt" value={prompt} onChange={e=>setPrompt(e.target.value)} maxLength={1500}
              placeholder={mode==="text" ? "A lone explorer walks through an abandoned city at sunrise, cinematic handheld camera..." : mode==="image" ? "The character slowly turns toward the camera, wind moves their hair and clothes..." : "A cinematic scene that keeps the character, outfit, and environment consistent across the references..."}/>
            <div className="charCount">{prompt.length}/1500</div>

            {mode !== "text" && <div className="uploadBlock">
              <div className="uploadHeading"><label className="fieldLabel">{mode==="image" ? "Source image" : "Reference images"}</label><span>{images.length}/{mode==="image" ? 1 : 5} uploaded</span></div>
              <div className="imageGrid">
                {images.map((img,i)=><div className="imageThumb" key={`${img.name}-${i}`}><img src={img.url} alt={img.name}/><button className="removeImage" onClick={()=>removeImage(i)} aria-label="Remove image"><X size={14}/></button><small>{img.name}</small></div>)}
                {images.length < (mode==="image" ? 1 : 5) && <button className="uploadTile" onClick={()=>inputRef.current?.click()}><Upload size={20}/><strong>Upload image</strong><small>JPG, PNG, WEBP</small></button>}
              </div>
              <input ref={inputRef} type="file" accept="image/*" multiple={mode==="reference"} hidden onChange={e=>addFiles(e.target.files)}/>
              {mode==="reference" && <p className="hint">Up to 5 images. Add character, location, costume, or style references.</p>}
            </div>}

            <div className="divider"/>
            <div className="panelHead settingsHead"><div><span className="step">02</span><h2>Video settings</h2></div></div>
            <div className="settingsGrid">
              <div>
                <label className="fieldLabel" htmlFor="duration"><Clock3 size={14}/> Duration</label>
                <select id="duration" value={duration} onChange={e=>setDuration(Number(e.target.value))}>
                  {[5,10,15,20,25,30].map(n=><option key={n} value={n}>{n} seconds</option>)}
                </select>
                <small className="hint">Maximum duration: 30 seconds</small>
              </div>
              <div>
                <label className="fieldLabel" htmlFor="ratio">Aspect ratio</label>
                <select id="ratio" value={ratio} onChange={e=>setRatio(e.target.value)}>
                  <option>16:9</option><option>9:16</option><option>1:1</option>
                </select>
                <small className="hint">Choose your video frame</small>
              </div>
            </div>
            <button className="generateBtn" onClick={generate} disabled={busy}>
              {busy ? <><span className="spinner"/> Creating demo request...</> : <><Sparkles size={18}/> Generate Video <span className="btnArrow">→</span></>}
            </button>
            {notice && <div className={`notice ${notice.kind}`}><span>{notice.kind==="success" ? <CheckCircle2 size={17}/> : <AlertCircle size={17}/>}</span>{notice.text}</div>}
          </section>

          <aside className="panel preview">
            <div className="previewTop"><div><span className="step">03</span><h2>Preview</h2></div><span className="previewTag">OUTPUT</span></div>
            <div className="previewCanvas">
              {job ? <div className="emptyPreview"><div className="previewGlyph"><CheckCircle2 size={28}/></div><strong>Demo request created</strong><p>Job ID: {job.id}</p><small>{job.message}</small></div> :
                <div className="emptyPreview"><div className="previewGlyph"><Play size={26} fill="currentColor"/></div><strong>Your video will appear here</strong><p>Set your prompt and generation options, then press Generate Video.</p></div>}
            </div>
            <div className="previewMeta"><span><Clock3 size={14}/> {duration}s</span><span>{ratio}</span><span>MP4 · when connected</span></div>
            <button className="downloadBtn" disabled><Download size={16}/> Download video <small>Not available in demo</small></button>
            <div className="demoNote"><Sparkles size={15}/><p><strong>Demo mode</strong><br/>This starter project checks your settings and creates a demo job only. Connect a real video-generation API to render and download videos.</p></div>
          </aside>
        </div>
      </section>
      <footer><span>FRAMEFLOW STUDIO</span><span>Built for learning · Mobile friendly</span></footer>
    </main>
  );
}
