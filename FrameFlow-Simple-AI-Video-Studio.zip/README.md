# FrameFlow — Simple AI Video Studio

A mobile-friendly learning starter for three workflows:
- Text to Video
- Image to Video
- Reference to Video (up to 5 images)

## Duration limit
The UI offers 5, 10, 15, 20, 25, and 30 seconds. The API validates a maximum of 30 seconds.

## Important: demo mode
This project does **not** generate real AI video yet. The `/api/generate` endpoint validates the request and returns a demo job ID. To render real videos, connect a video-generation provider on the server side and implement its upload, job polling, and result-download flow. Never expose provider API keys in browser code.

## Run locally / in a cloud editor
Requirements: Node.js 20+
```bash
npm install
npm run dev
```
Open the preview URL shown by your cloud editor.

## Free learning deployment
- Store the project in a GitHub repository.
- Edit/run it in a cloud development environment with a free quota (check current limits).
- Deploy the Next.js app to Vercel's free Hobby tier if eligible.
- Supabase and object storage can be added later if user accounts or persistent media storage are needed.

Free plans have usage limits and terms that can change. Check each provider's current pricing before deploying.

## Connect a real video provider
Implement the provider integration in `app/api/generate/route.ts` (or a separate server-only module). The API should:
1. Validate prompt, mode, duration, ratio, and uploaded files.
2. Upload source/reference images securely when required.
3. Submit a generation request to the provider using a server-side API key.
4. Return a provider job ID.
5. Add a status endpoint to poll progress and retrieve the finished MP4.
6. Store generated files in object storage before enabling Download.

The browser currently sends image filenames for demonstration only, not the actual image bytes. Implement secure file upload before connecting image-based generation.
